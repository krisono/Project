package PersonalProject.Project;
import java.util.Scanner;

public class InputName
{
    public static void main(String[] args) 
    {
        String name;
        String reservation;
       	Scanner input = new Scanner(System.in);
            
		System.out.println("Welcome To Kris' Kitchen");
		System.out.println("Whats your name?");
		name = input.nextLine();
		do
		{
			System.out.println(name +", Would you like a reservation or Order your food(R for reservation, M to make your orders and q to quit)?");
			reservation = input.nextLine();
			if (reservation.equalsIgnoreCase("R"))         
			{ 
				Reservation.reservationList();
			} 
          	else if (reservation.equalsIgnoreCase("M"))
            {
				Menu.Restaurant();
            }
          	else if (!reservation.equalsIgnoreCase("q"))
            {
              	System.out.println("Please enter R or C.");
            }
		}
		while(!reservation.equalsIgnoreCase("q"));
		System.out.println("End Of Program");
	}

    }
