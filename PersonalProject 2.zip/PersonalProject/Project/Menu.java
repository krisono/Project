package PersonalProject.Project;
import java.util.Scanner;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.*;  


class Menu 
{
    static Scanner input = new Scanner(System.in);
    public static Scanner scan=null;
    public static int print(String[] s)
    {
        for(int i=0; i<s.length; i++)
        {
            System.out.println((i+1)+"- "+s[i]);
        }
        System.out.print("Answer: ");
        int op = scan.nextInt()-1;
        return op;
    }
    public static int print(String[] s,int[] prices)
    {
        for(int i=0; i<s.length; i++)
        {
            System.out.printf("%-16s",((i+1)+"- "+s[i]));
            System.out.println("\t"+"$"+prices[i]);
        }
        System.out.print("Answer: ");
        int op = scan.nextInt()-1;
        return op;
    }
    public static void Restaurant() 
    {
        scan = new Scanner(System.in);
        String[] items = new String[]{"Sandwich","Subsandwich","Alfredo",};
        String[] Sandwich_types = new String[]{"Chicken","Steak","Pork"};
        int[] Sandwich_price = new int[]{11,15,13};
        String[] SubSandwich_types = new String[]{"5inch","8inch","12inch"};
        int[] SubSandwich_price = new int[]{15,21,27};
        String[] Alfredo_types = new String[]{"Chicken Alfredo","Shimp Alfredo","steak Alfredo"};
        int[] Alfredo_price = new int[]{15,20,20};
        String[] drinks = new String[] {"Sprite","Slushie","Water"};
        int[] drinks_price = new int[] {2,6,1};
        boolean valid = true;
        String item="",type = "",drink="";
        int total = 0;
        System.out.println("What drink would you like?");
        int item_index = print(items);
        if(item_index == 0) 
        {
            item = items[item_index];
            System.out.println("What type of Sandwich?");
            int type_index = print(Sandwich_types,Sandwich_price);
            if(type_index >=0 && type_index<3) 
            {
                total = Sandwich_price[type_index];
                type = Sandwich_types[type_index];
            }
            else 
            { 
                valid = false; 
            }
        }
        else if(item_index == 1) 
        {
            item = items[item_index];
            System.out.println("What type of Subsandwich?");
            int type_index = print(SubSandwich_types,SubSandwich_price);
            if(type_index >=0 && type_index<3) 
            {
                total = SubSandwich_price[type_index];
                type = SubSandwich_types[type_index];
            }
            else 
            { 
                valid = false; 
            }
        }
        else if(item_index == 2) 
        {
            item = items[item_index];
            System.out.println("What type of Alfredo?");
            int type_index = print(Alfredo_types,Alfredo_price);
            if(type_index >=0 && type_index<3) 
            {
                total = Alfredo_price[type_index];
                type = Alfredo_types[type_index];
            }
            else 
            { 
                valid = false; 
            }
        }
        else 
        {
            valid = false;
        }
        if(valid) 
        {
            System.out.println("What would you like to drink?");
            int drink_index = print(drinks,drinks_price);
            if(drink_index >=0 && drink_index<3) 
            {
                total = total + drinks_price[drink_index];
                drink = drinks[drink_index];
            }
            else 
            { 
                valid = false; 
            }
        }
        if(valid) 
        {
            System.out.print("Your order is: ");
            System.out.println(type+" "+item+" with "+drink+".");
            JOptionPane.showMessageDialog(null,"Your Total is: "+"$"+total);
            JLabel priceLabel = new JLabel("The price for your stay is");
            String input;
            input = JOptionPane.showInputDialog(null, "Enter account number");
            input = JOptionPane.showInputDialog(null, "Enter Your expire date");
            input = JOptionPane.showInputDialog(null, "Enter Your password");
            JCheckBox checkbox = new JCheckBox("Do not show this message again.");
            String message = "Pay now";
            Object[] params = {message, checkbox};
            int n = JOptionPane.showConfirmDialog(null, params, "Payment", JOptionPane.YES_NO_OPTION);
            boolean dontShow = checkbox.isSelected();
            JOptionPane.showMessageDialog(null,"Thanks for Dining with us at Kris' Kitchen");
        }
        else 
        {
            System.out.println("Try Again");
        }
        scan.close();
        System.exit(0); 
    }
}