package PersonalProject.Project;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.PrintWriter;
import java.io.File;

public class Reservation
{
    static Scanner reservationInput =new Scanner(System.in);
    static String[] name2=new String[30];
    static boolean[] check=new boolean[30];
  
    public static void reservationList()
    {
        System.out.print("\nPick from one of the following: ");
		System.out.print("\n1.Reserve a table\n2.Show Reservation list\n3.Order Menu\n0.End");
		int userInput = reservationInput.nextInt();
      	reservationInput.nextLine();
                if (userInput == 1) 
                {
                  System.out.print("Enter the name: ");
                  String name = reservationInput.nextLine();
                  //check[num]=true;
                  System.out.print("How many people? ");
            	  int num=reservationInput.nextInt();
           		  while (num>7)
                  {
                    System.out.println("Invalid Num, Enter a number from 0-7");
                    num = reservationInput.nextInt();
                  }
                  boolean isValidDate = false;
                  Date date = null;
                  System.out.print("\nWhat table would you like to reserve(pick from 0 to 30)? ");
		          int reserveNum=reservationInput.nextInt();
                  while (reserveNum>30 || reserveNum<0)
			      {
				    System.out.println("The table you chose isn't available.");
		            reserveNum=reservationInput.nextInt();	
                  }
                  System.out.println("Table "+reserveNum+" has been reserved for you.");
                  reservationInput.nextLine();
                  while (!isValidDate) {
                      try {
                          System.out.println("What time (yyyy-MM-dd hh:mm:ss)?");
                          while (!reservationInput.hasNextLine()) { }
                          String time = reservationInput.nextLine();
                          System.out.println(time);
                          SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                          date = format.parse(time);
                          isValidDate = true;
                        } 
                        catch (Exception ex) 
                      {
                          isValidDate = false;
                          System.out.println("Invalid date and time. Please enter in this format (yyyy-MM-dd hh:mm:ss)");
                      }
                  }

            JOptionPane.showMessageDialog(null, "Table" +reserveNum+" has been reserved for you on "+date);
		}
        if (userInput == 2) 
        {
            System.out.println("reservation.txt file created");
            PrintWriter pw;
            try {
                pw = new PrintWriter(new File("reservation.txt"));
                for (int i = 0; i < 30; i++) {
                    pw.println("Table number:" + i + "  Available");
                }
                pw.close ();
            }catch (Exception e) {
                System.out.println(e.getMessage());
            }  
        }
        if (userInput == 3) 
        {   
            Menu.Restaurant();
        }
        if (userInput == 0) 
        {
            System.out.println("End Of Program");
        }
    }          
}